package cucumberOption;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "src/test/java/features/register.feature",
       glue= {"stepDefinations"},
       monochrome=false,
       plugin = {"html:target/Destination"}
       )
public class TestRunner {

}
