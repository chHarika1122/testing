package stepDefinations;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementLocators.ElementLocator;

public class StepDefination {
	
	
	@Given("^Open the Browser$")
	public void open_the_Browser() throws Throwable {
		pageFactory.PageFactory.openbrowser();
	}

	@Given("^Open the Registeration Form$")
	public void open_the_Registeration_Form() throws Throwable {
		pageFactory.PageFactory.linkOpenLogin("file:///C:/Users/chharika/Desktop/WebPages/M4%20set2%20webpages/WebPages/RegistrationForm.html");
	}

	@When("^user validate the form Title$")
	public void user_validate_the_form_Title() throws Throwable {
		//pageFactory.PageFactory.verifyTitle();	    
	}

	@When("^Enter the user Id$")
	public void enter_the_user_Id() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.insertKeys(ElementLocator.userId, "2345671");
	}

	@When("^Enter the Password$")
	public void enter_the_Password() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.insertKeys(ElementLocator.password, "capg1234");	
	}

	@When("^Enter the user Name$")
	public void enter_the_user_Name() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(3000);
		pageFactory.PageFactory.insertKeys(ElementLocator.Name, "capgemini");
	}

	@When("^Enter the user address$")
	public void enter_the_user_address() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(3000);
		pageFactory.PageFactory.insertKeys(ElementLocator.address, "siruseri,Chennai");
	}

	@When("^select the Country$")
	public void select_the_Country() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(3000);
		pageFactory.PageFactory.select(ElementLocator.country);	
	}

	@When("^Enter the Zip Code$")
	public void enter_the_Zip_Code() throws Throwable {
		pageFactory.PageFactory.insertKeys(ElementLocator.zip, "hdgfhd343");
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.clearBox(ElementLocator.zip);
		pageFactory.PageFactory.insertKeys(ElementLocator.zip, "620055");		 
	}

	
	@When("^Enter the Email Id$")
	public void enter_the_Email_Id() throws Throwable{
		pageFactory.PageFactory.insertKeys(ElementLocator.email,"abcdhdgfifd");
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.clearBox(ElementLocator.email);
		pageFactory.PageFactory.insertKeys(ElementLocator.email,"abcdefrgd@gmail.com");	
	}

	@When("^Select the Sex$")
	public void select_the_Sex() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.clickMethod(ElementLocator.sex);	
	}

	@When("^Select the Language$")
	public void select_the_Language() throws Throwable {
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		pageFactory.PageFactory.alertHandler();
		Thread.sleep(1000);
		pageFactory.PageFactory.clickMethod(ElementLocator.language);	
	}

	@Then("^Click on Submit button$")
	public void click_on_Submit_button() throws Throwable {
		Thread.sleep(1000);
		pageFactory.PageFactory.clickMethod(ElementLocator.submit);	
	}

	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		Thread.sleep(1000);
		pageFactory.PageFactory.closeBrowser();
	}


}
