import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { angularOperation } from '../angularOperation';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  angOp: angularOperation[];
  service: ProductserviceService;
  

  constructor(service: ProductserviceService) {
    this.service = service;
  }

  ngOnInit() {
    this.service.fetchProduct();
    this.angOp = this.service.getProduct();
  }

  delete(id: string) {
    this.service.delete(id);
    this.angOp = this.service.getProduct();
  }
}
