import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { angularOperation } from './angularOperation';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  angOp: angularOperation[]=[];
  http: HttpClient;
  
  constructor(http: HttpClient) {
    this.http=http;
  }

  getProduct(): angularOperation[] {
    return this.angOp;
  }

  search(name: string): angularOperation[] {
    let result: angularOperation[]=[];
    this.angOp=this.getProduct();
    let s:angularOperation;    
    for(let i=0; i<this.angOp.length;i++) {
      s = this.angOp[i];
      if(name == s.name) {
        result.push(this.angOp[i]);
      }
      
      if(result[0]!=null) {
        return result;
      }
    }
  }
  
  
  fetch: boolean=false;
  fetchProduct() {
    this.http.get('./assets/db.json').subscribe(
      data => {
        if(!this.fetch)
        {
          this.convert(data);
          this.fetch=true;
        }
      });
    }


  convert(data: any) {
    for(let i of data)
    {
      let d=new angularOperation(i.id,i.name,i.price,i.category);
      this.angOp.push(d);
    }
  }

  delete(id: string) {
    let Index: number = -1;

    for (let i = 0; i < this.angOp.length; i++)
     {
        let c = this.angOp[i];
        if (id == c.id) {
          Index = i;
          break;
        }
      }
     this.angOp.splice(Index, 1);       
  }   
  
}
