import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { angularOperation } from '../angularOperation';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  service:ProductserviceService
  angOp:  angularOperation[]=[];
  
  constructor(service:ProductserviceService) {
    this.service= service;
   }

  ngOnInit() {
    this.service.fetchProduct();
  }
  
  search(data:any)
  {
    let name:string = data.name;
    this.angOp = this.service.search(name); //search through Product Name
  }

  isDisplay:boolean=true;  
  display()
  {
    this.isDisplay=!this.isDisplay
  } 
}
